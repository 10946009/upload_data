#!/usr/bin/env python 
# python!=
print((int(input())-15)%24)
