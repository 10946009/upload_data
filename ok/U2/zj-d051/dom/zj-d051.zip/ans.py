#!/usr/bin/env python 
# python!=
print('{:.3f}'.format((float(input())-32)* 5 / 9))
