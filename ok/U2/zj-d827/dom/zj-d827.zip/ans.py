#!/usr/bin/env python 
# python!=
a,b=divmod(int(input()),12)
print(a*50+b*5)
