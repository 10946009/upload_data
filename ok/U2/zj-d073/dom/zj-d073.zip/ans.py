#!/usr/bin/env python 
# python=
import math
print(math.ceil(float(input())/3))
