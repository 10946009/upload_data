#!/usr/bin/env python 
# python=
print(sum(list(map(int,input().split()))))
