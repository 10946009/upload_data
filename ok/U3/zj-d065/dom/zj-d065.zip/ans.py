#!/usr/bin/env python 
# python!=
print(max(list(map(int,(input()).split()))))
