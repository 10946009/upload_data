#!/usr/bin/env python 
# python!=
a=float(input())
print(int((a/max(abs(1**a*a),1))))
