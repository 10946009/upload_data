#!/usr/bin/env python 
# python!=
print("1" if int(input())%2 else "0")
