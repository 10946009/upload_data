#!/usr/bin/env python 
# python!=
print((lambda a : a-min((a//51),1))(int(input())))
