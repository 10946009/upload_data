#!/usr/bin/env python 
# python!=
print(int(input())^1)
