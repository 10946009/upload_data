#!/usr/bin/env python 
# python!=
print((60-(int(input())-25))%60)
