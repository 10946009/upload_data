#!/usr/bin/env python 
# python=
print("hello,",input())
